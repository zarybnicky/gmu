#GMU OpenGL compute shader labs

#Building Linux:
0. mkdir build/
1. cd build/
2. cmake ..
3. make

#Building on Windows:
0. cmake-gui
1. select source directory and build directory
2. configure, generate, open visual studio project
4. build

#Task:
0. Study the framework (src/main.cpp).
1. Implement compute shader for updating velocities according to Newton's law of universal gravitation in function createUpdateVelocityProgram in src/main.cpp.

#Notes:
use kappa uniform variable as gravitational constant
if two particles are too close to each other, clamp the force so it does not go to infinity.
